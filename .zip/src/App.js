
import './App.css';
import { RouterMain } from './App/Router/Router';

function App() {
  return (
    <div className="App">
      <RouterMain/>
    </div>
  );
}

export default App;
